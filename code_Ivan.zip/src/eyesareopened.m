function resp = eyesareopened(name, xl, yl, xr, yr)
    coord = eyesdetect(name);
    resp=0;
    resp = 0.5*isopenedfft(name, xl, yl)+0.5*isopenedfft(name, xr, yr);
end